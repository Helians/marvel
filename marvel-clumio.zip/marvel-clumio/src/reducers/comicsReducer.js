import { comicActions } from "../actions/comicActions"

// comic store schema
export const initialComicsState = {
    comics: [],
    total: 0,
    characters: [],
    searchkey: '',
    characterFilterList: [],
    pageNumber: 1
}

// reducer function to handle actions
export const comicsReducer = (state, action) => {
    switch (action.type) {

        case comicActions.SET_COMICS:
            return {
                ...state,
                comics: [...action.comics],
                total: action.total
            }

        case comicActions.SET_SEARCHKEY:
            return {
                ...state,
                searchkey: action.searchkey,
                characterFilterList: [],
                pageNumber: 1
            }

        case comicActions.SET_FILTER_CHARACTERS:
            return {
                ...state,
                characterFilterList: [...action.characterFilterList],
                pageNumber: 1
            }

        case comicActions.SET_CHARACTERS:
            return {
                ...state,
                characters: [...action.characters]
            }

        case comicActions.CLEAR_FILTERS:
            return {
                ...state,
                characterFilterList: [],
                pageNumber: 1
            }

        case comicActions.CHANGE_PAGENUMBER:
            return {
                ...state,
                pageNumber: action.pageNumber
            }

        default: return { ...state }
    }
}
