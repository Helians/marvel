import { Layout } from "../components/layout/Layout"
import { Home } from "./Home"

export const Pages = () => {
    return (
        <Layout>
            <Home />
        </Layout>
    )
}
