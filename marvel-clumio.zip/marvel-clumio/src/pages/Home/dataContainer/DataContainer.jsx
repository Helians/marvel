import React, { useEffect, useState } from 'react';
import { Card } from './../../../components/card/Card';
import { useComicsContext } from '../../../providers/ComicsProvider';
import './DataContainer.css';
import { Pagination } from '../../../components/pagination/Pagination';
import { useQuery } from 'react-query';
import { getAllComics } from '../../../services/marvelServices';
import { comicActions } from '../../../actions/comicActions';
import { Container } from '../../../components/layout/Container';


export const DataContainer = () => {
    const [{ comics, total, searchkey, characterFilterList, pageNumber }, dispatch] = useComicsContext();
    const { data, isLoading } = useQuery(['fetchComicsData', pageNumber, searchkey, characterFilterList], () => getAllComics({ pageNumber, searchText: searchkey, characters: characterFilterList.map(obj => obj.id) }))

    // handle page change
    const handlePageChange = (pageIndex) => {
        dispatch({
            type: comicActions.CHANGE_PAGENUMBER,
            pageNumber: pageIndex.selected + 1
        })
    }

    useEffect(() => {
        if (data) {
            dispatch({
                type: comicActions.SET_COMICS,
                comics: [...data.results],
                total: data.total
            })
        }
    }, [data])

    const clearFilters = () => {
        dispatch({
            type: comicActions.CLEAR_FILTERS
        })
    }

    return (
        <Container>
            <section className='dataContaner'>
                {searchkey && <h2 className='dataContainer__filters'>Search Results</h2>}
                {characterFilterList?.length &&
                    <h2 className='dataContainer__filters'>
                        <span className='dataContainer__filter-text'>Explore - {characterFilterList.map(obj => obj.name).join(' , ')}</span>
                        <button onClick={clearFilters} className='dataContainer__filter__button-clear'>Clear all filters</button>
                    </h2>}

                {isLoading ? <div className='dataContainer__loading'>Loading...</div> :
                    comics.length ? <>
                        <div className='dataContaner__wrapper'>
                            {comics.map((d) => (
                                <Card
                                    key={d.id + `${Date.now()}`}
                                    title={(d.title).replace(`#${d.issueNumber}`, '')}
                                    rank={d.issueNumber ? `#${d.issueNumber}` : ''}
                                    imgUrl={d.thumbnail.path + '.' + d.thumbnail.extension}
                                />
                            ))}
                        </div>

                        <Pagination pageCount={Math.ceil(total / 20)} pageOffset={20} handlePageChange={handlePageChange} />
                    </> : <div className='dataContainer__loading'>No Data found</div>
                }
            </section>
        </Container>
    )
}
