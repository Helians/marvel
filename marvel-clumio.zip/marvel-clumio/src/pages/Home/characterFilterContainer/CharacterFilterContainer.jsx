import React, { useCallback, useEffect, useState, useRef } from 'react';
import { useQuery } from 'react-query';
import { comicActions } from '../../../actions/comicActions';
import { useComicsContext } from '../../../providers/ComicsProvider';
import { getAllCharacters } from '../../../services/marvelServices';
import { Carousel } from '../../../components/carousel/Carousel';
import { Container } from '../../../components/layout/Container';
import { SelectFilter } from '../../../components/selectFilter/SelectFilter';
import './CharacterFilterContainer.css';

export const CharacterFilterContainer = () => {

    const [{ characters, searchkey, characterFilterList }, dispatch] = useComicsContext();
    const [pageNumber, setPageNumber] = useState(1);
    const imgRef = useRef(null);
    const observer = useRef(null);
    const { data } = useQuery(['characters', pageNumber], () => getAllCharacters({ pageNumber }));

    useEffect(() => {
        if (data) {
            dispatch({
                type: comicActions.SET_CHARACTERS,
                characters: [...characters, ...data.results]
            })
            console.log(characters)
        }
    }, [data])

    // filter by characters
    const handleSelect = useCallback(({ id, name }) => {
        let selectedCharacters = [...characterFilterList];
        const index = selectedCharacters.findIndex(obj => obj.id == id);
        if (index > -1) {
            selectedCharacters.splice(index, 1);
        } else {
            selectedCharacters = [...selectedCharacters, { id, name }]
        }

        dispatch({
            type: comicActions.RESET_PAGE,
            startPage: 1
        })

        dispatch({
            type: comicActions.SET_FILTER_CHARACTERS,
            characterFilterList: [...selectedCharacters]
        })

        

    }, [characterFilterList])

    // infinite scroll using intersection observer
    useEffect(() => {
        if (observer.current) {
            observer.current.disconnect()
        }

        observer.current = new IntersectionObserver(entries => {
            if (entries[0].isIntersecting) {
                setPageNumber(prev => prev + 1)
            }
        })

        if (imgRef.current) {
            observer.current.observe(imgRef.current)
        }
    }, [characters])


    return (
        <section className='characterFilterContiner'>
            <Container>
                <Carousel itemList={characters?.map((character, index) =>
                    <SelectFilter
                        key={character.id}
                        id={character.id}
                        title={character.title}
                        image={character.thumbnail.path + '.' + character.thumbnail.extension}
                        handleSelect={handleSelect}
                        isSelected={characterFilterList.find(obj => obj.id == character.id)}
                        isDisabled={!!searchkey}
                        ref={(index == characters.length - 1) ? imgRef : null}
                        name={character.name}
                    />)} />
            </Container>
        </section>
    )
} 