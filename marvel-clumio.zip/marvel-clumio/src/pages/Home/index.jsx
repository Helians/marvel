import React from 'react';
import { CharacterFilterContainer } from './characterFilterContainer/CharacterFilterContainer';
import { DataContainer } from "./dataContainer/DataContainer";

export const Home = () => {
    return (
        <>
        <CharacterFilterContainer />
        <DataContainer />
        </>
    )
}
