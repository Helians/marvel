import React from 'react';
import './Carousel.css';

export const Carousel = ({ itemList }) => {
    return (
        <div className='carousel'>
            {itemList.map(item => item)}
        </div>
    )
} 
