import React from 'react';
import './Card.css';

export const Card = ({ title, isLazyLoad = true, imgUrl, rank }) => {
    return (
        <div className='card'>
            <figure className='card__wrapper'>
                <img className='card__image' alt={title} title={title} src={imgUrl} loading={isLazyLoad ? 'lazy' : 'eager'} />
                <figcaption className='card__caption'>
                    <span className='card__caption__text'>{title}</span>
                    <span className='card__caption__rank'>{rank}</span>
                </figcaption>
            </figure>
        </div>
    )
} 
