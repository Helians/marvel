import React from 'react';
import './Search.css';

export const Search = ({ placeholder, handleChangeCallback }) => {

    const handleChange = (e) => {
        handleChangeCallback(e.target.value)
    }

    return (
        <div className='search'>
            <input
                className='search__input'
                placeholder={placeholder || ''}
                onChange={handleChange}
            />
        </div>
    )
}