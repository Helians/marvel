import React from 'react';
import ReactPaginate from 'react-paginate';
import './Pagination.css';

export const Pagination = ({ pageCount, handlePageChange, pageOffset }) => {
    return (
        <div className='pagination'>
            <ReactPaginate
                previousLabel="<"
                nextLabel=">"
                pageClassName="pagination__page-item"
                pageLinkClassName="pagination__page-link"
                previousClassName="pagination__page-item"
                previousLinkClassName="pagination__page-link"
                nextClassName="pagination__page-item"
                nextLinkClassName="pagination__page-link"
                breakLabel="..."
                breakClassName="pagination__page-item"
                breakLinkClassName="pagination__page-link"
                marginPagesDisplayed={5}
                pageRangeDisplayed={1}
                containerClassName="pagination__container"
                activeClassName="pagination__page-active"
                pageCount={pageCount}
                onPageChange={handlePageChange}
                forcePage={pageOffset}
            />
        </div>
    )
}