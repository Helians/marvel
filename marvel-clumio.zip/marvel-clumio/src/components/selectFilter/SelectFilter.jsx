import React, { forwardRef } from 'react';
import './SelectFilter.css';

export const SelectFilter = forwardRef(({ id, name, image, title, isSelected, handleSelect, isLazyLoading = true, isDisabled = false }, imgRef) => {

    return (
        <section className='selectFilter' ref={imgRef}>
            <div className={`selectFilter__container ${isDisabled ? 'selectFilter__selected-disabled' : ''}`} onClick={isDisabled ? () => {} : () => handleSelect({id, name})}>
                <img src={image} title={title} alt={title} className='selectFilter__image' loading={isLazyLoading ? 'lazy' : 'eager'} />
                {(isSelected || isDisabled) && <div className='selectFilter__selected'>
                    {!isDisabled && <span className={`selectFilter__selected__icon ${isDisabled ? '' : 'selectFilter__selected-bordered'}`}></span>}
                </div>}
            </div>
        </section>
    )
})