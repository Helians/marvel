import React, { useCallback, useEffect, useState } from 'react';
import { Container } from '../Container';
import marvelLogo from './../../../assets/marvelLogo.png'
import { Search } from '../../search/Search';
import { useComicsContext } from '../../../providers/ComicsProvider';
import { comicActions } from '../../../actions/comicActions';
import { debounce } from '../../../utils/debounce';
import './Header.css';

export const Header = () => {

    const [, dispatch] = useComicsContext();
    const [searchText, setSearchText] = useState('');

    // debounce on search
    const handleSearch = useCallback(debounce((value) => {
        setSearchText((value || '').trim())
    }, 500), [])

    // check for data and save it in comic store
    useEffect(() => {
        dispatch({
            type: comicActions.SET_SEARCHKEY,
            searchkey: searchText
        });
        // dispatch({
        //     type: comicActions.SET_FILTER_CHARACTERS,
        //     characterFilterList: []
        // })
        // dispatch({
        //     type: comicActions.RESET_PAGE,
        //     startPage: 1
        // })
    }, [searchText])

    return (
        <header className='header'>
            <Container>
                <div className='header__container'>
                    <img className='header__logo' src={marvelLogo} alt='marvel logo' title='marvel logo' />
                    <div className='header__search'>
                        <Search placeholder={'Search by comic titles'} handleChangeCallback={handleSearch} />
                    </div>
                </div>
            </Container>
        </header>
    )
} 
