import React from 'react';
import { Header } from './header/Header';
import './Layout.css';

export const Layout = ({ children }) => {
    return (
        <section className='layout'>
            <Header />
            {children}
        </section>
    )
} 