import React, { createContext, useContext, useReducer } from "react";

const ComicsStateContext = createContext();

// comic provider
export const ComicsProvider = ({ children, reducer, initialComicsState }) => (
    <ComicsStateContext.Provider value={useReducer(reducer, initialComicsState)}>
        {children}
    </ComicsStateContext.Provider>
)

// comic context
export const useComicsContext = () => useContext(ComicsStateContext);
