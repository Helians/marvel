import { CONFIG } from "../configs/config";

// api to get comics
export const getAllComics = ({ searchText, pageNumber = 1, limit = 20, characters = [] }) => {
    let offset = (pageNumber - 1) * limit;
    return fetch(`${CONFIG.MARVEL_DOMAIN}/comics?limit=${limit}&offset=${offset}${characters?.length ? `&characters=${characters}` : ''}&apikey=${CONFIG.MARVEL_API_KEY}${searchText ? `&title=${searchText}` : ''}`).then(res => res.json()).then(res => res.data);
}

// api to get characters
export const getAllCharacters = ({ limit = 20, pageNumber = 1 }) => {
    let offset = (pageNumber - 1) * limit;
    return fetch(`${CONFIG.MARVEL_DOMAIN}/characters?limit=${limit}&offset=${offset}&apikey=${CONFIG.MARVEL_API_KEY}`).then(res => res.json()).then(res => res.data);
}
