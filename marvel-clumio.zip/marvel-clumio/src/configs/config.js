export const CONFIG = {
    MARVEL_DOMAIN: 'https://gateway.marvel.com:443/v1/public',
    MARVEL_API_KEY: 'publickey' // put your own public key
}