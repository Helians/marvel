// debounce method
export function debounce(cb, delay) {
    let intervalId = null;
    return function (...args) {
        if (intervalId) {
            clearTimeout(intervalId)
        }
        
        intervalId = setTimeout(cb.bind(this, ...args), delay)
    }
}
