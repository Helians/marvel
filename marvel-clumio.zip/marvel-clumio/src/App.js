import './App.css';
import { Pages } from './pages';
import { ComicsProvider } from './providers/ComicsProvider';
import { comicsReducer, initialComicsState } from './reducers/comicsReducer';
import { QueryClientProvider, QueryClient } from 'react-query';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="app">
        <ComicsProvider reducer={comicsReducer} initialComicsState={initialComicsState}>
          <Pages />
        </ComicsProvider>
      </div>
    </QueryClientProvider>
  );
}

export default App;
